﻿namespace BlueMarble
{
    partial class MainBoard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainBoard));
            pbArea1 = new System.Windows.Forms.PictureBox();
            pbArea0 = new System.Windows.Forms.PictureBox();
            pbArea31 = new System.Windows.Forms.PictureBox();
            pbGoldKey = new System.Windows.Forms.PictureBox();
            pbArea2 = new System.Windows.Forms.PictureBox();
            pbArea3 = new System.Windows.Forms.PictureBox();
            pbArea6 = new System.Windows.Forms.PictureBox();
            pbArea5 = new System.Windows.Forms.PictureBox();
            pbArea4 = new System.Windows.Forms.PictureBox();
            pbArea7 = new System.Windows.Forms.PictureBox();
            pbArea8 = new System.Windows.Forms.PictureBox();
            pbArea30 = new System.Windows.Forms.PictureBox();
            pbArea26 = new System.Windows.Forms.PictureBox();
            pbArea27 = new System.Windows.Forms.PictureBox();
            pbArea28 = new System.Windows.Forms.PictureBox();
            pbArea25 = new System.Windows.Forms.PictureBox();
            pbArea24 = new System.Windows.Forms.PictureBox();
            pbArea16 = new System.Windows.Forms.PictureBox();
            pbArea17 = new System.Windows.Forms.PictureBox();
            pbArea18 = new System.Windows.Forms.PictureBox();
            pbArea19 = new System.Windows.Forms.PictureBox();
            pbArea20 = new System.Windows.Forms.PictureBox();
            pbArea21 = new System.Windows.Forms.PictureBox();
            pbArea22 = new System.Windows.Forms.PictureBox();
            pbArea23 = new System.Windows.Forms.PictureBox();
            pbArea15 = new System.Windows.Forms.PictureBox();
            pbArea14 = new System.Windows.Forms.PictureBox();
            pbArea13 = new System.Windows.Forms.PictureBox();
            pbArea12 = new System.Windows.Forms.PictureBox();
            pbArea11 = new System.Windows.Forms.PictureBox();
            pbArea10 = new System.Windows.Forms.PictureBox();
            pbArea9 = new System.Windows.Forms.PictureBox();
            pbImage = new System.Windows.Forms.PictureBox();
            pbPlayer1_1 = new System.Windows.Forms.PictureBox();
            pbPlayer2_1 = new System.Windows.Forms.PictureBox();
            pbPlayer2_2 = new System.Windows.Forms.PictureBox();
            pbPlayer1_2 = new System.Windows.Forms.PictureBox();
            pbPlayer2_4 = new System.Windows.Forms.PictureBox();
            pbPlayer1_4 = new System.Windows.Forms.PictureBox();
            pbPlayer2_6 = new System.Windows.Forms.PictureBox();
            pbPlayer1_6 = new System.Windows.Forms.PictureBox();
            pbPlayer2_7 = new System.Windows.Forms.PictureBox();
            pbPlayer1_7 = new System.Windows.Forms.PictureBox();
            pbPlayer1_9 = new System.Windows.Forms.PictureBox();
            pbPlayer2_9 = new System.Windows.Forms.PictureBox();
            pbPlayer2_10 = new System.Windows.Forms.PictureBox();
            pbPlayer1_10 = new System.Windows.Forms.PictureBox();
            pbPlayer2_12 = new System.Windows.Forms.PictureBox();
            pbPlayer1_12 = new System.Windows.Forms.PictureBox();
            pbPlayer2_13 = new System.Windows.Forms.PictureBox();
            pbPlayer1_13 = new System.Windows.Forms.PictureBox();
            pbPlayer2_15 = new System.Windows.Forms.PictureBox();
            pbPlayer1_15 = new System.Windows.Forms.PictureBox();
            pbPlayer1_17 = new System.Windows.Forms.PictureBox();
            pbPlayer2_17 = new System.Windows.Forms.PictureBox();
            pbPlayer1_18 = new System.Windows.Forms.PictureBox();
            pbPlayer2_18 = new System.Windows.Forms.PictureBox();
            pbPlayer1_20 = new System.Windows.Forms.PictureBox();
            pbPlayer2_20 = new System.Windows.Forms.PictureBox();
            pbPlayer1_22 = new System.Windows.Forms.PictureBox();
            pbPlayer2_22 = new System.Windows.Forms.PictureBox();
            pbPlayer1_23 = new System.Windows.Forms.PictureBox();
            pbPlayer2_23 = new System.Windows.Forms.PictureBox();
            pbPlayer1_25 = new System.Windows.Forms.PictureBox();
            pbPlayer2_25 = new System.Windows.Forms.PictureBox();
            pbPlayer1_26 = new System.Windows.Forms.PictureBox();
            pbPlayer2_26 = new System.Windows.Forms.PictureBox();
            pbPlayer1_28 = new System.Windows.Forms.PictureBox();
            pbPlayer2_28 = new System.Windows.Forms.PictureBox();
            pbPlayer1_29 = new System.Windows.Forms.PictureBox();
            pbPlayer2_29 = new System.Windows.Forms.PictureBox();
            pbPlayer1_31 = new System.Windows.Forms.PictureBox();
            pbPlayer2_31 = new System.Windows.Forms.PictureBox();
            pbPlayer1_27 = new System.Windows.Forms.PictureBox();
            pbPlayer2_27 = new System.Windows.Forms.PictureBox();
            pbPlayer1_30 = new System.Windows.Forms.PictureBox();
            pbPlayer2_30 = new System.Windows.Forms.PictureBox();
            pbPlayer2_11 = new System.Windows.Forms.PictureBox();
            pbPlayer1_11 = new System.Windows.Forms.PictureBox();
            pbPlayer2_14 = new System.Windows.Forms.PictureBox();
            pbPlayer1_14 = new System.Windows.Forms.PictureBox();
            pbPlayer1_19 = new System.Windows.Forms.PictureBox();
            pbPlayer2_19 = new System.Windows.Forms.PictureBox();
            pbPlayer1_21 = new System.Windows.Forms.PictureBox();
            pbPlayer2_21 = new System.Windows.Forms.PictureBox();
            pbPlayer1_16 = new System.Windows.Forms.PictureBox();
            pbPlayer2_16 = new System.Windows.Forms.PictureBox();
            pbPlayer1_24 = new System.Windows.Forms.PictureBox();
            pbPlayer2_24 = new System.Windows.Forms.PictureBox();
            pbPlayer2_0 = new System.Windows.Forms.PictureBox();
            pbPlayer1_0 = new System.Windows.Forms.PictureBox();
            pbPlayer2_8 = new System.Windows.Forms.PictureBox();
            pbPlayer1_8 = new System.Windows.Forms.PictureBox();
            pbPlayer2_3 = new System.Windows.Forms.PictureBox();
            pbPlayer1_3 = new System.Windows.Forms.PictureBox();
            pbPlayer2_5 = new System.Windows.Forms.PictureBox();
            pbPlayer1_5 = new System.Windows.Forms.PictureBox();
            pbBuild0 = new System.Windows.Forms.PictureBox();
            pbArea29 = new System.Windows.Forms.PictureBox();
            pbBuild1 = new System.Windows.Forms.PictureBox();
            pbBuild2 = new System.Windows.Forms.PictureBox();
            pbBuild3 = new System.Windows.Forms.PictureBox();
            pbBuild4 = new System.Windows.Forms.PictureBox();
            pbBuild5 = new System.Windows.Forms.PictureBox();
            pbBuild6 = new System.Windows.Forms.PictureBox();
            pbBuild7 = new System.Windows.Forms.PictureBox();
            pbBuild8 = new System.Windows.Forms.PictureBox();
            pbBuild9 = new System.Windows.Forms.PictureBox();
            pbBuild10 = new System.Windows.Forms.PictureBox();
            pbBuild11 = new System.Windows.Forms.PictureBox();
            pbBuild13 = new System.Windows.Forms.PictureBox();
            pbBuild12 = new System.Windows.Forms.PictureBox();
            pbBuild14 = new System.Windows.Forms.PictureBox();
            pbBuild15 = new System.Windows.Forms.PictureBox();
            pbBuild16 = new System.Windows.Forms.PictureBox();
            pbBuild17 = new System.Windows.Forms.PictureBox();
            pbBuild18 = new System.Windows.Forms.PictureBox();
            pbBuild19 = new System.Windows.Forms.PictureBox();
            pbBuild20 = new System.Windows.Forms.PictureBox();
            pbBuild21 = new System.Windows.Forms.PictureBox();
            pbBuild22 = new System.Windows.Forms.PictureBox();
            lbTurn = new System.Windows.Forms.Label();
            lbPlayer1 = new System.Windows.Forms.Label();
            lbPlayer2 = new System.Windows.Forms.Label();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            imageList1 = new System.Windows.Forms.ImageList(components);
            timer3 = new System.Windows.Forms.Timer(components);
            lbDice2 = new System.Windows.Forms.Label();
            lbDice1 = new System.Windows.Forms.Label();
            pbDice1 = new System.Windows.Forms.PictureBox();
            pbDice2 = new System.Windows.Forms.PictureBox();
            btnShowArea1 = new System.Windows.Forms.Button();
            btnShowArea2 = new System.Windows.Forms.Button();
            pbDice = new System.Windows.Forms.PictureBox();
            imageList2 = new System.Windows.Forms.ImageList(components);
            pbFundCoin = new System.Windows.Forms.PictureBox();
            imageList3 = new System.Windows.Forms.ImageList(components);
            ((System.ComponentModel.ISupportInitialize)pbArea1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea0).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea31).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbGoldKey).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea30).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbImage).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_31).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_31).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_30).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_30).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_0).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_0).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild0).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbArea29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbDice1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbDice2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbDice).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbFundCoin).BeginInit();
            SuspendLayout();
            // 
            // pbArea1
            // 
            pbArea1.BackColor = System.Drawing.Color.Transparent;
            pbArea1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea1.Image = (System.Drawing.Image)resources.GetObject("pbArea1.Image");
            pbArea1.Location = new System.Drawing.Point(128, 834);
            pbArea1.Margin = new System.Windows.Forms.Padding(0);
            pbArea1.Name = "pbArea1";
            pbArea1.Size = new System.Drawing.Size(100, 133);
            pbArea1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea1.TabIndex = 8;
            pbArea1.TabStop = false;
            pbArea1.Click += pbArea1_Click;
            // 
            // pbArea0
            // 
            pbArea0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea0.Image = (System.Drawing.Image)resources.GetObject("pbArea0.Image");
            pbArea0.Location = new System.Drawing.Point(0, 834);
            pbArea0.Margin = new System.Windows.Forms.Padding(0);
            pbArea0.Name = "pbArea0";
            pbArea0.Size = new System.Drawing.Size(128, 133);
            pbArea0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea0.TabIndex = 7;
            pbArea0.TabStop = false;
            pbArea0.Click += pbArea0_Click;
            // 
            // pbArea31
            // 
            pbArea31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea31.Image = (System.Drawing.Image)resources.GetObject("pbArea31.Image");
            pbArea31.Location = new System.Drawing.Point(0, 734);
            pbArea31.Margin = new System.Windows.Forms.Padding(0);
            pbArea31.Name = "pbArea31";
            pbArea31.Size = new System.Drawing.Size(128, 100);
            pbArea31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea31.TabIndex = 12;
            pbArea31.TabStop = false;
            pbArea31.Click += pbArea31_Click;
            // 
            // pbGoldKey
            // 
            pbGoldKey.Image = (System.Drawing.Image)resources.GetObject("pbGoldKey.Image");
            pbGoldKey.Location = new System.Drawing.Point(181, 181);
            pbGoldKey.Margin = new System.Windows.Forms.Padding(0);
            pbGoldKey.Name = "pbGoldKey";
            pbGoldKey.Size = new System.Drawing.Size(263, 100);
            pbGoldKey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbGoldKey.TabIndex = 37;
            pbGoldKey.TabStop = false;
            // 
            // pbArea2
            // 
            pbArea2.BackColor = System.Drawing.Color.Transparent;
            pbArea2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea2.Image = (System.Drawing.Image)resources.GetObject("pbArea2.Image");
            pbArea2.Location = new System.Drawing.Point(228, 834);
            pbArea2.Margin = new System.Windows.Forms.Padding(0);
            pbArea2.Name = "pbArea2";
            pbArea2.Size = new System.Drawing.Size(100, 133);
            pbArea2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea2.TabIndex = 38;
            pbArea2.TabStop = false;
            pbArea2.Click += pbArea2_Click;
            // 
            // pbArea3
            // 
            pbArea3.BackColor = System.Drawing.Color.Transparent;
            pbArea3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea3.Image = (System.Drawing.Image)resources.GetObject("pbArea3.Image");
            pbArea3.Location = new System.Drawing.Point(328, 834);
            pbArea3.Margin = new System.Windows.Forms.Padding(0);
            pbArea3.Name = "pbArea3";
            pbArea3.Size = new System.Drawing.Size(100, 133);
            pbArea3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea3.TabIndex = 39;
            pbArea3.TabStop = false;
            pbArea3.Click += pbArea3_Click;
            // 
            // pbArea6
            // 
            pbArea6.BackColor = System.Drawing.Color.Transparent;
            pbArea6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea6.Image = (System.Drawing.Image)resources.GetObject("pbArea6.Image");
            pbArea6.Location = new System.Drawing.Point(628, 834);
            pbArea6.Margin = new System.Windows.Forms.Padding(0);
            pbArea6.Name = "pbArea6";
            pbArea6.Size = new System.Drawing.Size(100, 133);
            pbArea6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea6.TabIndex = 42;
            pbArea6.TabStop = false;
            pbArea6.Click += pbArea6_Click;
            // 
            // pbArea5
            // 
            pbArea5.BackColor = System.Drawing.Color.Transparent;
            pbArea5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea5.Image = (System.Drawing.Image)resources.GetObject("pbArea5.Image");
            pbArea5.Location = new System.Drawing.Point(528, 834);
            pbArea5.Margin = new System.Windows.Forms.Padding(0);
            pbArea5.Name = "pbArea5";
            pbArea5.Size = new System.Drawing.Size(100, 133);
            pbArea5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea5.TabIndex = 41;
            pbArea5.TabStop = false;
            pbArea5.Click += pbArea5_Click;
            // 
            // pbArea4
            // 
            pbArea4.BackColor = System.Drawing.Color.Transparent;
            pbArea4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea4.Image = (System.Drawing.Image)resources.GetObject("pbArea4.Image");
            pbArea4.Location = new System.Drawing.Point(428, 834);
            pbArea4.Margin = new System.Windows.Forms.Padding(0);
            pbArea4.Name = "pbArea4";
            pbArea4.Size = new System.Drawing.Size(100, 133);
            pbArea4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea4.TabIndex = 40;
            pbArea4.TabStop = false;
            pbArea4.Click += pbArea4_Click;
            // 
            // pbArea7
            // 
            pbArea7.BackColor = System.Drawing.Color.Transparent;
            pbArea7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea7.Image = (System.Drawing.Image)resources.GetObject("pbArea7.Image");
            pbArea7.Location = new System.Drawing.Point(728, 834);
            pbArea7.Margin = new System.Windows.Forms.Padding(0);
            pbArea7.Name = "pbArea7";
            pbArea7.Size = new System.Drawing.Size(100, 133);
            pbArea7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea7.TabIndex = 43;
            pbArea7.TabStop = false;
            pbArea7.Click += pbArea7_Click;
            // 
            // pbArea8
            // 
            pbArea8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea8.Image = (System.Drawing.Image)resources.GetObject("pbArea8.Image");
            pbArea8.Location = new System.Drawing.Point(828, 834);
            pbArea8.Margin = new System.Windows.Forms.Padding(0);
            pbArea8.Name = "pbArea8";
            pbArea8.Size = new System.Drawing.Size(128, 133);
            pbArea8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea8.TabIndex = 44;
            pbArea8.TabStop = false;
            pbArea8.Click += pbArea8_Click;
            // 
            // pbArea30
            // 
            pbArea30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea30.Image = (System.Drawing.Image)resources.GetObject("pbArea30.Image");
            pbArea30.Location = new System.Drawing.Point(0, 634);
            pbArea30.Margin = new System.Windows.Forms.Padding(0);
            pbArea30.Name = "pbArea30";
            pbArea30.Size = new System.Drawing.Size(128, 100);
            pbArea30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea30.TabIndex = 45;
            pbArea30.TabStop = false;
            pbArea30.Click += pbArea30_Click;
            // 
            // pbArea26
            // 
            pbArea26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea26.Image = (System.Drawing.Image)resources.GetObject("pbArea26.Image");
            pbArea26.Location = new System.Drawing.Point(0, 234);
            pbArea26.Margin = new System.Windows.Forms.Padding(0);
            pbArea26.Name = "pbArea26";
            pbArea26.Size = new System.Drawing.Size(128, 100);
            pbArea26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea26.TabIndex = 49;
            pbArea26.TabStop = false;
            pbArea26.Click += pbArea26_Click;
            // 
            // pbArea27
            // 
            pbArea27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea27.Image = (System.Drawing.Image)resources.GetObject("pbArea27.Image");
            pbArea27.Location = new System.Drawing.Point(0, 334);
            pbArea27.Margin = new System.Windows.Forms.Padding(0);
            pbArea27.Name = "pbArea27";
            pbArea27.Size = new System.Drawing.Size(128, 100);
            pbArea27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea27.TabIndex = 48;
            pbArea27.TabStop = false;
            pbArea27.Click += pbArea27_Click;
            // 
            // pbArea28
            // 
            pbArea28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea28.Image = (System.Drawing.Image)resources.GetObject("pbArea28.Image");
            pbArea28.Location = new System.Drawing.Point(0, 434);
            pbArea28.Margin = new System.Windows.Forms.Padding(0);
            pbArea28.Name = "pbArea28";
            pbArea28.Size = new System.Drawing.Size(128, 100);
            pbArea28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea28.TabIndex = 47;
            pbArea28.TabStop = false;
            pbArea28.Click += pbArea28_Click;
            // 
            // pbArea25
            // 
            pbArea25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea25.Image = (System.Drawing.Image)resources.GetObject("pbArea25.Image");
            pbArea25.Location = new System.Drawing.Point(0, 134);
            pbArea25.Margin = new System.Windows.Forms.Padding(0);
            pbArea25.Name = "pbArea25";
            pbArea25.Size = new System.Drawing.Size(128, 100);
            pbArea25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea25.TabIndex = 50;
            pbArea25.TabStop = false;
            pbArea25.Click += pbArea25_Click;
            // 
            // pbArea24
            // 
            pbArea24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea24.Image = (System.Drawing.Image)resources.GetObject("pbArea24.Image");
            pbArea24.Location = new System.Drawing.Point(0, 1);
            pbArea24.Margin = new System.Windows.Forms.Padding(0);
            pbArea24.Name = "pbArea24";
            pbArea24.Size = new System.Drawing.Size(128, 133);
            pbArea24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea24.TabIndex = 51;
            pbArea24.TabStop = false;
            // 
            // pbArea16
            // 
            pbArea16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea16.Image = (System.Drawing.Image)resources.GetObject("pbArea16.Image");
            pbArea16.Location = new System.Drawing.Point(828, 1);
            pbArea16.Margin = new System.Windows.Forms.Padding(0);
            pbArea16.Name = "pbArea16";
            pbArea16.Size = new System.Drawing.Size(128, 133);
            pbArea16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea16.TabIndex = 59;
            pbArea16.TabStop = false;
            pbArea16.Click += pbArea16_Click;
            // 
            // pbArea17
            // 
            pbArea17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea17.Image = (System.Drawing.Image)resources.GetObject("pbArea17.Image");
            pbArea17.Location = new System.Drawing.Point(728, 1);
            pbArea17.Margin = new System.Windows.Forms.Padding(0);
            pbArea17.Name = "pbArea17";
            pbArea17.Size = new System.Drawing.Size(100, 133);
            pbArea17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea17.TabIndex = 58;
            pbArea17.TabStop = false;
            pbArea17.Click += pbArea17_Click;
            // 
            // pbArea18
            // 
            pbArea18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea18.Image = (System.Drawing.Image)resources.GetObject("pbArea18.Image");
            pbArea18.Location = new System.Drawing.Point(628, 1);
            pbArea18.Margin = new System.Windows.Forms.Padding(0);
            pbArea18.Name = "pbArea18";
            pbArea18.Size = new System.Drawing.Size(100, 133);
            pbArea18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea18.TabIndex = 57;
            pbArea18.TabStop = false;
            pbArea18.Click += pbArea18_Click;
            // 
            // pbArea19
            // 
            pbArea19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea19.Image = (System.Drawing.Image)resources.GetObject("pbArea19.Image");
            pbArea19.Location = new System.Drawing.Point(528, 1);
            pbArea19.Margin = new System.Windows.Forms.Padding(0);
            pbArea19.Name = "pbArea19";
            pbArea19.Size = new System.Drawing.Size(100, 133);
            pbArea19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea19.TabIndex = 56;
            pbArea19.TabStop = false;
            pbArea19.Click += pbArea19_Click;
            // 
            // pbArea20
            // 
            pbArea20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea20.Image = (System.Drawing.Image)resources.GetObject("pbArea20.Image");
            pbArea20.Location = new System.Drawing.Point(428, 1);
            pbArea20.Margin = new System.Windows.Forms.Padding(0);
            pbArea20.Name = "pbArea20";
            pbArea20.Size = new System.Drawing.Size(100, 133);
            pbArea20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea20.TabIndex = 55;
            pbArea20.TabStop = false;
            pbArea20.Click += pbArea20_Click;
            // 
            // pbArea21
            // 
            pbArea21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea21.Image = (System.Drawing.Image)resources.GetObject("pbArea21.Image");
            pbArea21.Location = new System.Drawing.Point(328, 1);
            pbArea21.Margin = new System.Windows.Forms.Padding(0);
            pbArea21.Name = "pbArea21";
            pbArea21.Size = new System.Drawing.Size(100, 133);
            pbArea21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea21.TabIndex = 54;
            pbArea21.TabStop = false;
            pbArea21.Click += pbArea21_Click;
            // 
            // pbArea22
            // 
            pbArea22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea22.Image = (System.Drawing.Image)resources.GetObject("pbArea22.Image");
            pbArea22.Location = new System.Drawing.Point(228, 1);
            pbArea22.Margin = new System.Windows.Forms.Padding(0);
            pbArea22.Name = "pbArea22";
            pbArea22.Size = new System.Drawing.Size(100, 133);
            pbArea22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea22.TabIndex = 53;
            pbArea22.TabStop = false;
            pbArea22.Click += pbArea22_Click;
            // 
            // pbArea23
            // 
            pbArea23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea23.Image = (System.Drawing.Image)resources.GetObject("pbArea23.Image");
            pbArea23.Location = new System.Drawing.Point(128, 1);
            pbArea23.Margin = new System.Windows.Forms.Padding(0);
            pbArea23.Name = "pbArea23";
            pbArea23.Size = new System.Drawing.Size(100, 133);
            pbArea23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea23.TabIndex = 52;
            pbArea23.TabStop = false;
            pbArea23.Click += pbArea23_Click;
            // 
            // pbArea15
            // 
            pbArea15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea15.Image = (System.Drawing.Image)resources.GetObject("pbArea15.Image");
            pbArea15.Location = new System.Drawing.Point(828, 134);
            pbArea15.Margin = new System.Windows.Forms.Padding(0);
            pbArea15.Name = "pbArea15";
            pbArea15.Size = new System.Drawing.Size(128, 100);
            pbArea15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea15.TabIndex = 66;
            pbArea15.TabStop = false;
            pbArea15.Click += pbArea15_Click;
            // 
            // pbArea14
            // 
            pbArea14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea14.Image = (System.Drawing.Image)resources.GetObject("pbArea14.Image");
            pbArea14.Location = new System.Drawing.Point(828, 234);
            pbArea14.Margin = new System.Windows.Forms.Padding(0);
            pbArea14.Name = "pbArea14";
            pbArea14.Size = new System.Drawing.Size(128, 100);
            pbArea14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea14.TabIndex = 65;
            pbArea14.TabStop = false;
            pbArea14.Click += pbArea14_Click;
            // 
            // pbArea13
            // 
            pbArea13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea13.Image = (System.Drawing.Image)resources.GetObject("pbArea13.Image");
            pbArea13.Location = new System.Drawing.Point(828, 334);
            pbArea13.Margin = new System.Windows.Forms.Padding(0);
            pbArea13.Name = "pbArea13";
            pbArea13.Size = new System.Drawing.Size(128, 100);
            pbArea13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea13.TabIndex = 64;
            pbArea13.TabStop = false;
            pbArea13.Click += pbArea13_Click;
            // 
            // pbArea12
            // 
            pbArea12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea12.Image = (System.Drawing.Image)resources.GetObject("pbArea12.Image");
            pbArea12.Location = new System.Drawing.Point(828, 434);
            pbArea12.Margin = new System.Windows.Forms.Padding(0);
            pbArea12.Name = "pbArea12";
            pbArea12.Size = new System.Drawing.Size(128, 100);
            pbArea12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea12.TabIndex = 63;
            pbArea12.TabStop = false;
            pbArea12.Click += pbArea12_Click;
            // 
            // pbArea11
            // 
            pbArea11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea11.Image = (System.Drawing.Image)resources.GetObject("pbArea11.Image");
            pbArea11.Location = new System.Drawing.Point(828, 534);
            pbArea11.Margin = new System.Windows.Forms.Padding(0);
            pbArea11.Name = "pbArea11";
            pbArea11.Size = new System.Drawing.Size(128, 100);
            pbArea11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea11.TabIndex = 62;
            pbArea11.TabStop = false;
            pbArea11.Click += pbArea11_Click;
            // 
            // pbArea10
            // 
            pbArea10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea10.Image = (System.Drawing.Image)resources.GetObject("pbArea10.Image");
            pbArea10.Location = new System.Drawing.Point(828, 634);
            pbArea10.Margin = new System.Windows.Forms.Padding(0);
            pbArea10.Name = "pbArea10";
            pbArea10.Size = new System.Drawing.Size(128, 100);
            pbArea10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea10.TabIndex = 61;
            pbArea10.TabStop = false;
            pbArea10.Click += pbArea10_Click;
            // 
            // pbArea9
            // 
            pbArea9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea9.Image = (System.Drawing.Image)resources.GetObject("pbArea9.Image");
            pbArea9.Location = new System.Drawing.Point(828, 734);
            pbArea9.Margin = new System.Windows.Forms.Padding(0);
            pbArea9.Name = "pbArea9";
            pbArea9.Size = new System.Drawing.Size(128, 100);
            pbArea9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea9.TabIndex = 60;
            pbArea9.TabStop = false;
            pbArea9.Click += pbArea9_Click;
            // 
            // pbImage
            // 
            pbImage.Image = (System.Drawing.Image)resources.GetObject("pbImage.Image");
            pbImage.Location = new System.Drawing.Point(245, 354);
            pbImage.Margin = new System.Windows.Forms.Padding(0);
            pbImage.Name = "pbImage";
            pbImage.Size = new System.Drawing.Size(460, 343);
            pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbImage.TabIndex = 67;
            pbImage.TabStop = false;
            // 
            // pbPlayer1_1
            // 
            pbPlayer1_1.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_1.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_1.Image");
            pbPlayer1_1.Location = new System.Drawing.Point(139, 907);
            pbPlayer1_1.Name = "pbPlayer1_1";
            pbPlayer1_1.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_1.TabIndex = 68;
            pbPlayer1_1.TabStop = false;
            pbPlayer1_1.Visible = false;
            // 
            // pbPlayer2_1
            // 
            pbPlayer2_1.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_1.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_1.Image");
            pbPlayer2_1.Location = new System.Drawing.Point(181, 907);
            pbPlayer2_1.Name = "pbPlayer2_1";
            pbPlayer2_1.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_1.TabIndex = 69;
            pbPlayer2_1.TabStop = false;
            pbPlayer2_1.Visible = false;
            // 
            // pbPlayer2_2
            // 
            pbPlayer2_2.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_2.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_2.Image");
            pbPlayer2_2.Location = new System.Drawing.Point(281, 907);
            pbPlayer2_2.Name = "pbPlayer2_2";
            pbPlayer2_2.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_2.TabIndex = 72;
            pbPlayer2_2.TabStop = false;
            pbPlayer2_2.Visible = false;
            // 
            // pbPlayer1_2
            // 
            pbPlayer1_2.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_2.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_2.Image");
            pbPlayer1_2.Location = new System.Drawing.Point(239, 907);
            pbPlayer1_2.Name = "pbPlayer1_2";
            pbPlayer1_2.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_2.TabIndex = 71;
            pbPlayer1_2.TabStop = false;
            pbPlayer1_2.Visible = false;
            // 
            // pbPlayer2_4
            // 
            pbPlayer2_4.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_4.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_4.Image");
            pbPlayer2_4.Location = new System.Drawing.Point(481, 907);
            pbPlayer2_4.Name = "pbPlayer2_4";
            pbPlayer2_4.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_4.TabIndex = 74;
            pbPlayer2_4.TabStop = false;
            pbPlayer2_4.Visible = false;
            // 
            // pbPlayer1_4
            // 
            pbPlayer1_4.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_4.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_4.Image");
            pbPlayer1_4.Location = new System.Drawing.Point(439, 907);
            pbPlayer1_4.Name = "pbPlayer1_4";
            pbPlayer1_4.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_4.TabIndex = 73;
            pbPlayer1_4.TabStop = false;
            pbPlayer1_4.Visible = false;
            // 
            // pbPlayer2_6
            // 
            pbPlayer2_6.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_6.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_6.Image");
            pbPlayer2_6.Location = new System.Drawing.Point(680, 907);
            pbPlayer2_6.Name = "pbPlayer2_6";
            pbPlayer2_6.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_6.TabIndex = 76;
            pbPlayer2_6.TabStop = false;
            pbPlayer2_6.Visible = false;
            // 
            // pbPlayer1_6
            // 
            pbPlayer1_6.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_6.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_6.Image");
            pbPlayer1_6.Location = new System.Drawing.Point(638, 907);
            pbPlayer1_6.Name = "pbPlayer1_6";
            pbPlayer1_6.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_6.TabIndex = 75;
            pbPlayer1_6.TabStop = false;
            pbPlayer1_6.Visible = false;
            // 
            // pbPlayer2_7
            // 
            pbPlayer2_7.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_7.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_7.Image");
            pbPlayer2_7.Location = new System.Drawing.Point(781, 907);
            pbPlayer2_7.Name = "pbPlayer2_7";
            pbPlayer2_7.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_7.TabIndex = 78;
            pbPlayer2_7.TabStop = false;
            pbPlayer2_7.Visible = false;
            // 
            // pbPlayer1_7
            // 
            pbPlayer1_7.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_7.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_7.Image");
            pbPlayer1_7.Location = new System.Drawing.Point(739, 907);
            pbPlayer1_7.Name = "pbPlayer1_7";
            pbPlayer1_7.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_7.TabIndex = 77;
            pbPlayer1_7.TabStop = false;
            pbPlayer1_7.Visible = false;
            // 
            // pbPlayer1_9
            // 
            pbPlayer1_9.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_9.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_9.Image");
            pbPlayer1_9.Location = new System.Drawing.Point(892, 789);
            pbPlayer1_9.Name = "pbPlayer1_9";
            pbPlayer1_9.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_9.TabIndex = 79;
            pbPlayer1_9.TabStop = false;
            pbPlayer1_9.Visible = false;
            // 
            // pbPlayer2_9
            // 
            pbPlayer2_9.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_9.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_9.Image");
            pbPlayer2_9.Location = new System.Drawing.Point(892, 747);
            pbPlayer2_9.Name = "pbPlayer2_9";
            pbPlayer2_9.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_9.TabIndex = 80;
            pbPlayer2_9.TabStop = false;
            pbPlayer2_9.Visible = false;
            // 
            // pbPlayer2_10
            // 
            pbPlayer2_10.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_10.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_10.Image");
            pbPlayer2_10.Location = new System.Drawing.Point(892, 647);
            pbPlayer2_10.Name = "pbPlayer2_10";
            pbPlayer2_10.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_10.TabIndex = 82;
            pbPlayer2_10.TabStop = false;
            pbPlayer2_10.Visible = false;
            // 
            // pbPlayer1_10
            // 
            pbPlayer1_10.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_10.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_10.Image");
            pbPlayer1_10.Location = new System.Drawing.Point(892, 689);
            pbPlayer1_10.Name = "pbPlayer1_10";
            pbPlayer1_10.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_10.TabIndex = 81;
            pbPlayer1_10.TabStop = false;
            pbPlayer1_10.Visible = false;
            // 
            // pbPlayer2_12
            // 
            pbPlayer2_12.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_12.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_12.Image");
            pbPlayer2_12.Location = new System.Drawing.Point(891, 445);
            pbPlayer2_12.Name = "pbPlayer2_12";
            pbPlayer2_12.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_12.TabIndex = 84;
            pbPlayer2_12.TabStop = false;
            pbPlayer2_12.Visible = false;
            // 
            // pbPlayer1_12
            // 
            pbPlayer1_12.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_12.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_12.Image");
            pbPlayer1_12.Location = new System.Drawing.Point(891, 487);
            pbPlayer1_12.Name = "pbPlayer1_12";
            pbPlayer1_12.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_12.TabIndex = 83;
            pbPlayer1_12.TabStop = false;
            pbPlayer1_12.Visible = false;
            // 
            // pbPlayer2_13
            // 
            pbPlayer2_13.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_13.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_13.Image");
            pbPlayer2_13.Location = new System.Drawing.Point(891, 346);
            pbPlayer2_13.Name = "pbPlayer2_13";
            pbPlayer2_13.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_13.TabIndex = 86;
            pbPlayer2_13.TabStop = false;
            pbPlayer2_13.Visible = false;
            // 
            // pbPlayer1_13
            // 
            pbPlayer1_13.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_13.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_13.Image");
            pbPlayer1_13.Location = new System.Drawing.Point(891, 388);
            pbPlayer1_13.Name = "pbPlayer1_13";
            pbPlayer1_13.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_13.TabIndex = 85;
            pbPlayer1_13.TabStop = false;
            pbPlayer1_13.Visible = false;
            // 
            // pbPlayer2_15
            // 
            pbPlayer2_15.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_15.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_15.Image");
            pbPlayer2_15.Location = new System.Drawing.Point(892, 145);
            pbPlayer2_15.Name = "pbPlayer2_15";
            pbPlayer2_15.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_15.TabIndex = 88;
            pbPlayer2_15.TabStop = false;
            pbPlayer2_15.Visible = false;
            // 
            // pbPlayer1_15
            // 
            pbPlayer1_15.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_15.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_15.Image");
            pbPlayer1_15.Location = new System.Drawing.Point(892, 187);
            pbPlayer1_15.Name = "pbPlayer1_15";
            pbPlayer1_15.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_15.TabIndex = 87;
            pbPlayer1_15.TabStop = false;
            pbPlayer1_15.Visible = false;
            // 
            // pbPlayer1_17
            // 
            pbPlayer1_17.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_17.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_17.Image");
            pbPlayer1_17.Location = new System.Drawing.Point(781, 12);
            pbPlayer1_17.Name = "pbPlayer1_17";
            pbPlayer1_17.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_17.TabIndex = 90;
            pbPlayer1_17.TabStop = false;
            pbPlayer1_17.Visible = false;
            // 
            // pbPlayer2_17
            // 
            pbPlayer2_17.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_17.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_17.Image");
            pbPlayer2_17.Location = new System.Drawing.Point(739, 12);
            pbPlayer2_17.Name = "pbPlayer2_17";
            pbPlayer2_17.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_17.TabIndex = 89;
            pbPlayer2_17.TabStop = false;
            pbPlayer2_17.Visible = false;
            // 
            // pbPlayer1_18
            // 
            pbPlayer1_18.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_18.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_18.Image");
            pbPlayer1_18.Location = new System.Drawing.Point(680, 12);
            pbPlayer1_18.Name = "pbPlayer1_18";
            pbPlayer1_18.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_18.TabIndex = 92;
            pbPlayer1_18.TabStop = false;
            pbPlayer1_18.Visible = false;
            // 
            // pbPlayer2_18
            // 
            pbPlayer2_18.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_18.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_18.Image");
            pbPlayer2_18.Location = new System.Drawing.Point(638, 12);
            pbPlayer2_18.Name = "pbPlayer2_18";
            pbPlayer2_18.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_18.TabIndex = 91;
            pbPlayer2_18.TabStop = false;
            pbPlayer2_18.Visible = false;
            // 
            // pbPlayer1_20
            // 
            pbPlayer1_20.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_20.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_20.Image");
            pbPlayer1_20.Location = new System.Drawing.Point(481, 12);
            pbPlayer1_20.Name = "pbPlayer1_20";
            pbPlayer1_20.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_20.TabIndex = 94;
            pbPlayer1_20.TabStop = false;
            pbPlayer1_20.Visible = false;
            // 
            // pbPlayer2_20
            // 
            pbPlayer2_20.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_20.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_20.Image");
            pbPlayer2_20.Location = new System.Drawing.Point(439, 12);
            pbPlayer2_20.Name = "pbPlayer2_20";
            pbPlayer2_20.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_20.TabIndex = 93;
            pbPlayer2_20.TabStop = false;
            pbPlayer2_20.Visible = false;
            // 
            // pbPlayer1_22
            // 
            pbPlayer1_22.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_22.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_22.Image");
            pbPlayer1_22.Location = new System.Drawing.Point(281, 12);
            pbPlayer1_22.Name = "pbPlayer1_22";
            pbPlayer1_22.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_22.TabIndex = 96;
            pbPlayer1_22.TabStop = false;
            pbPlayer1_22.Visible = false;
            // 
            // pbPlayer2_22
            // 
            pbPlayer2_22.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_22.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_22.Image");
            pbPlayer2_22.Location = new System.Drawing.Point(239, 12);
            pbPlayer2_22.Name = "pbPlayer2_22";
            pbPlayer2_22.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_22.TabIndex = 95;
            pbPlayer2_22.TabStop = false;
            pbPlayer2_22.Visible = false;
            // 
            // pbPlayer1_23
            // 
            pbPlayer1_23.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_23.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_23.Image");
            pbPlayer1_23.Location = new System.Drawing.Point(181, 12);
            pbPlayer1_23.Name = "pbPlayer1_23";
            pbPlayer1_23.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_23.TabIndex = 98;
            pbPlayer1_23.TabStop = false;
            pbPlayer1_23.Visible = false;
            // 
            // pbPlayer2_23
            // 
            pbPlayer2_23.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_23.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_23.Image");
            pbPlayer2_23.Location = new System.Drawing.Point(139, 12);
            pbPlayer2_23.Name = "pbPlayer2_23";
            pbPlayer2_23.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_23.TabIndex = 97;
            pbPlayer2_23.TabStop = false;
            pbPlayer2_23.Visible = false;
            // 
            // pbPlayer1_25
            // 
            pbPlayer1_25.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_25.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_25.Image");
            pbPlayer1_25.Location = new System.Drawing.Point(12, 145);
            pbPlayer1_25.Name = "pbPlayer1_25";
            pbPlayer1_25.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_25.TabIndex = 100;
            pbPlayer1_25.TabStop = false;
            pbPlayer1_25.Visible = false;
            // 
            // pbPlayer2_25
            // 
            pbPlayer2_25.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_25.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_25.Image");
            pbPlayer2_25.Location = new System.Drawing.Point(12, 187);
            pbPlayer2_25.Name = "pbPlayer2_25";
            pbPlayer2_25.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_25.TabIndex = 99;
            pbPlayer2_25.TabStop = false;
            pbPlayer2_25.Visible = false;
            // 
            // pbPlayer1_26
            // 
            pbPlayer1_26.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_26.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_26.Image");
            pbPlayer1_26.Location = new System.Drawing.Point(12, 245);
            pbPlayer1_26.Name = "pbPlayer1_26";
            pbPlayer1_26.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_26.TabIndex = 102;
            pbPlayer1_26.TabStop = false;
            pbPlayer1_26.Visible = false;
            // 
            // pbPlayer2_26
            // 
            pbPlayer2_26.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_26.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_26.Image");
            pbPlayer2_26.Location = new System.Drawing.Point(12, 287);
            pbPlayer2_26.Name = "pbPlayer2_26";
            pbPlayer2_26.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_26.TabIndex = 101;
            pbPlayer2_26.TabStop = false;
            pbPlayer2_26.Visible = false;
            // 
            // pbPlayer1_28
            // 
            pbPlayer1_28.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_28.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_28.Image");
            pbPlayer1_28.Location = new System.Drawing.Point(12, 445);
            pbPlayer1_28.Name = "pbPlayer1_28";
            pbPlayer1_28.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_28.TabIndex = 104;
            pbPlayer1_28.TabStop = false;
            pbPlayer1_28.Visible = false;
            // 
            // pbPlayer2_28
            // 
            pbPlayer2_28.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_28.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_28.Image");
            pbPlayer2_28.Location = new System.Drawing.Point(12, 487);
            pbPlayer2_28.Name = "pbPlayer2_28";
            pbPlayer2_28.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_28.TabIndex = 103;
            pbPlayer2_28.TabStop = false;
            pbPlayer2_28.Visible = false;
            // 
            // pbPlayer1_29
            // 
            pbPlayer1_29.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_29.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_29.Image");
            pbPlayer1_29.Location = new System.Drawing.Point(12, 546);
            pbPlayer1_29.Name = "pbPlayer1_29";
            pbPlayer1_29.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_29.TabIndex = 106;
            pbPlayer1_29.TabStop = false;
            pbPlayer1_29.Visible = false;
            // 
            // pbPlayer2_29
            // 
            pbPlayer2_29.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_29.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_29.Image");
            pbPlayer2_29.Location = new System.Drawing.Point(12, 588);
            pbPlayer2_29.Name = "pbPlayer2_29";
            pbPlayer2_29.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_29.TabIndex = 105;
            pbPlayer2_29.TabStop = false;
            pbPlayer2_29.Visible = false;
            // 
            // pbPlayer1_31
            // 
            pbPlayer1_31.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_31.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_31.Image");
            pbPlayer1_31.Location = new System.Drawing.Point(12, 747);
            pbPlayer1_31.Name = "pbPlayer1_31";
            pbPlayer1_31.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_31.TabIndex = 108;
            pbPlayer1_31.TabStop = false;
            pbPlayer1_31.Visible = false;
            // 
            // pbPlayer2_31
            // 
            pbPlayer2_31.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_31.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_31.Image");
            pbPlayer2_31.Location = new System.Drawing.Point(12, 789);
            pbPlayer2_31.Name = "pbPlayer2_31";
            pbPlayer2_31.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_31.TabIndex = 107;
            pbPlayer2_31.TabStop = false;
            pbPlayer2_31.Visible = false;
            // 
            // pbPlayer1_27
            // 
            pbPlayer1_27.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_27.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_27.Image");
            pbPlayer1_27.Location = new System.Drawing.Point(12, 346);
            pbPlayer1_27.Name = "pbPlayer1_27";
            pbPlayer1_27.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_27.TabIndex = 110;
            pbPlayer1_27.TabStop = false;
            pbPlayer1_27.Visible = false;
            // 
            // pbPlayer2_27
            // 
            pbPlayer2_27.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_27.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_27.Image");
            pbPlayer2_27.Location = new System.Drawing.Point(12, 388);
            pbPlayer2_27.Name = "pbPlayer2_27";
            pbPlayer2_27.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_27.TabIndex = 109;
            pbPlayer2_27.TabStop = false;
            pbPlayer2_27.Visible = false;
            // 
            // pbPlayer1_30
            // 
            pbPlayer1_30.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_30.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_30.Image");
            pbPlayer1_30.Location = new System.Drawing.Point(12, 647);
            pbPlayer1_30.Name = "pbPlayer1_30";
            pbPlayer1_30.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_30.TabIndex = 112;
            pbPlayer1_30.TabStop = false;
            pbPlayer1_30.Visible = false;
            // 
            // pbPlayer2_30
            // 
            pbPlayer2_30.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_30.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_30.Image");
            pbPlayer2_30.Location = new System.Drawing.Point(12, 689);
            pbPlayer2_30.Name = "pbPlayer2_30";
            pbPlayer2_30.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_30.TabIndex = 111;
            pbPlayer2_30.TabStop = false;
            pbPlayer2_30.Visible = false;
            // 
            // pbPlayer2_11
            // 
            pbPlayer2_11.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_11.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_11.Image");
            pbPlayer2_11.Location = new System.Drawing.Point(892, 546);
            pbPlayer2_11.Name = "pbPlayer2_11";
            pbPlayer2_11.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_11.TabIndex = 114;
            pbPlayer2_11.TabStop = false;
            pbPlayer2_11.Visible = false;
            // 
            // pbPlayer1_11
            // 
            pbPlayer1_11.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_11.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_11.Image");
            pbPlayer1_11.Location = new System.Drawing.Point(892, 588);
            pbPlayer1_11.Name = "pbPlayer1_11";
            pbPlayer1_11.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_11.TabIndex = 113;
            pbPlayer1_11.TabStop = false;
            pbPlayer1_11.Visible = false;
            // 
            // pbPlayer2_14
            // 
            pbPlayer2_14.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_14.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_14.Image");
            pbPlayer2_14.Location = new System.Drawing.Point(892, 245);
            pbPlayer2_14.Name = "pbPlayer2_14";
            pbPlayer2_14.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_14.TabIndex = 116;
            pbPlayer2_14.TabStop = false;
            pbPlayer2_14.Visible = false;
            // 
            // pbPlayer1_14
            // 
            pbPlayer1_14.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_14.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_14.Image");
            pbPlayer1_14.Location = new System.Drawing.Point(892, 287);
            pbPlayer1_14.Name = "pbPlayer1_14";
            pbPlayer1_14.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_14.TabIndex = 115;
            pbPlayer1_14.TabStop = false;
            pbPlayer1_14.Visible = false;
            // 
            // pbPlayer1_19
            // 
            pbPlayer1_19.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_19.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_19.Image");
            pbPlayer1_19.Location = new System.Drawing.Point(580, 12);
            pbPlayer1_19.Name = "pbPlayer1_19";
            pbPlayer1_19.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_19.TabIndex = 118;
            pbPlayer1_19.TabStop = false;
            pbPlayer1_19.Visible = false;
            // 
            // pbPlayer2_19
            // 
            pbPlayer2_19.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_19.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_19.Image");
            pbPlayer2_19.Location = new System.Drawing.Point(538, 12);
            pbPlayer2_19.Name = "pbPlayer2_19";
            pbPlayer2_19.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_19.TabIndex = 117;
            pbPlayer2_19.TabStop = false;
            pbPlayer2_19.Visible = false;
            // 
            // pbPlayer1_21
            // 
            pbPlayer1_21.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_21.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_21.Image");
            pbPlayer1_21.Location = new System.Drawing.Point(380, 12);
            pbPlayer1_21.Name = "pbPlayer1_21";
            pbPlayer1_21.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_21.TabIndex = 120;
            pbPlayer1_21.TabStop = false;
            pbPlayer1_21.Visible = false;
            // 
            // pbPlayer2_21
            // 
            pbPlayer2_21.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_21.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_21.Image");
            pbPlayer2_21.Location = new System.Drawing.Point(338, 12);
            pbPlayer2_21.Name = "pbPlayer2_21";
            pbPlayer2_21.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_21.TabIndex = 119;
            pbPlayer2_21.TabStop = false;
            pbPlayer2_21.Visible = false;
            // 
            // pbPlayer1_16
            // 
            pbPlayer1_16.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_16.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_16.Image");
            pbPlayer1_16.Location = new System.Drawing.Point(903, 60);
            pbPlayer1_16.Name = "pbPlayer1_16";
            pbPlayer1_16.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_16.TabIndex = 122;
            pbPlayer1_16.TabStop = false;
            pbPlayer1_16.Visible = false;
            // 
            // pbPlayer2_16
            // 
            pbPlayer2_16.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_16.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_16.Image");
            pbPlayer2_16.Location = new System.Drawing.Point(861, 60);
            pbPlayer2_16.Name = "pbPlayer2_16";
            pbPlayer2_16.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_16.TabIndex = 121;
            pbPlayer2_16.TabStop = false;
            pbPlayer2_16.Visible = false;
            // 
            // pbPlayer1_24
            // 
            pbPlayer1_24.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_24.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_24.Image");
            pbPlayer1_24.Location = new System.Drawing.Point(12, 30);
            pbPlayer1_24.Name = "pbPlayer1_24";
            pbPlayer1_24.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_24.TabIndex = 124;
            pbPlayer1_24.TabStop = false;
            pbPlayer1_24.Visible = false;
            // 
            // pbPlayer2_24
            // 
            pbPlayer2_24.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_24.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_24.Image");
            pbPlayer2_24.Location = new System.Drawing.Point(12, 72);
            pbPlayer2_24.Name = "pbPlayer2_24";
            pbPlayer2_24.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_24.TabIndex = 123;
            pbPlayer2_24.TabStop = false;
            pbPlayer2_24.Visible = false;
            // 
            // pbPlayer2_0
            // 
            pbPlayer2_0.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_0.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_0.Image");
            pbPlayer2_0.Location = new System.Drawing.Point(63, 883);
            pbPlayer2_0.Name = "pbPlayer2_0";
            pbPlayer2_0.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_0.TabIndex = 126;
            pbPlayer2_0.TabStop = false;
            pbPlayer2_0.Visible = false;
            // 
            // pbPlayer1_0
            // 
            pbPlayer1_0.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_0.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_0.Image");
            pbPlayer1_0.Location = new System.Drawing.Point(21, 883);
            pbPlayer1_0.Name = "pbPlayer1_0";
            pbPlayer1_0.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_0.TabIndex = 125;
            pbPlayer1_0.TabStop = false;
            pbPlayer1_0.Visible = false;
            // 
            // pbPlayer2_8
            // 
            pbPlayer2_8.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_8.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_8.Image");
            pbPlayer2_8.Location = new System.Drawing.Point(892, 878);
            pbPlayer2_8.Name = "pbPlayer2_8";
            pbPlayer2_8.Size = new System.Drawing.Size(54, 36);
            pbPlayer2_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_8.TabIndex = 128;
            pbPlayer2_8.TabStop = false;
            pbPlayer2_8.Visible = false;
            // 
            // pbPlayer1_8
            // 
            pbPlayer1_8.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_8.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_8.Image");
            pbPlayer1_8.Location = new System.Drawing.Point(891, 920);
            pbPlayer1_8.Name = "pbPlayer1_8";
            pbPlayer1_8.Size = new System.Drawing.Size(54, 36);
            pbPlayer1_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_8.TabIndex = 127;
            pbPlayer1_8.TabStop = false;
            pbPlayer1_8.Visible = false;
            // 
            // pbPlayer2_3
            // 
            pbPlayer2_3.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_3.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_3.Image");
            pbPlayer2_3.Location = new System.Drawing.Point(382, 907);
            pbPlayer2_3.Name = "pbPlayer2_3";
            pbPlayer2_3.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_3.TabIndex = 130;
            pbPlayer2_3.TabStop = false;
            pbPlayer2_3.Visible = false;
            // 
            // pbPlayer1_3
            // 
            pbPlayer1_3.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_3.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_3.Image");
            pbPlayer1_3.Location = new System.Drawing.Point(340, 907);
            pbPlayer1_3.Name = "pbPlayer1_3";
            pbPlayer1_3.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_3.TabIndex = 129;
            pbPlayer1_3.TabStop = false;
            pbPlayer1_3.Visible = false;
            // 
            // pbPlayer2_5
            // 
            pbPlayer2_5.BackColor = System.Drawing.Color.Transparent;
            pbPlayer2_5.Image = (System.Drawing.Image)resources.GetObject("pbPlayer2_5.Image");
            pbPlayer2_5.Location = new System.Drawing.Point(580, 907);
            pbPlayer2_5.Name = "pbPlayer2_5";
            pbPlayer2_5.Size = new System.Drawing.Size(36, 54);
            pbPlayer2_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer2_5.TabIndex = 132;
            pbPlayer2_5.TabStop = false;
            pbPlayer2_5.Visible = false;
            // 
            // pbPlayer1_5
            // 
            pbPlayer1_5.BackColor = System.Drawing.Color.Transparent;
            pbPlayer1_5.Image = (System.Drawing.Image)resources.GetObject("pbPlayer1_5.Image");
            pbPlayer1_5.Location = new System.Drawing.Point(538, 907);
            pbPlayer1_5.Name = "pbPlayer1_5";
            pbPlayer1_5.Size = new System.Drawing.Size(36, 54);
            pbPlayer1_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbPlayer1_5.TabIndex = 131;
            pbPlayer1_5.TabStop = false;
            pbPlayer1_5.Visible = false;
            // 
            // pbBuild0
            // 
            pbBuild0.BackColor = System.Drawing.Color.Transparent;
            pbBuild0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild0.Location = new System.Drawing.Point(152, 835);
            pbBuild0.Name = "pbBuild0";
            pbBuild0.Size = new System.Drawing.Size(50, 40);
            pbBuild0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild0.TabIndex = 159;
            pbBuild0.TabStop = false;
            pbBuild0.Visible = false;
            // 
            // pbArea29
            // 
            pbArea29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbArea29.Image = (System.Drawing.Image)resources.GetObject("pbArea29.Image");
            pbArea29.Location = new System.Drawing.Point(0, 534);
            pbArea29.Margin = new System.Windows.Forms.Padding(0);
            pbArea29.Name = "pbArea29";
            pbArea29.Size = new System.Drawing.Size(128, 100);
            pbArea29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbArea29.TabIndex = 46;
            pbArea29.TabStop = false;
            pbArea29.Click += pbArea29_Click;
            // 
            // pbBuild1
            // 
            pbBuild1.BackColor = System.Drawing.Color.Transparent;
            pbBuild1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild1.Location = new System.Drawing.Point(253, 834);
            pbBuild1.Name = "pbBuild1";
            pbBuild1.Size = new System.Drawing.Size(50, 40);
            pbBuild1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild1.TabIndex = 160;
            pbBuild1.TabStop = false;
            pbBuild1.Visible = false;
            // 
            // pbBuild2
            // 
            pbBuild2.BackColor = System.Drawing.Color.Transparent;
            pbBuild2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild2.Location = new System.Drawing.Point(351, 834);
            pbBuild2.Name = "pbBuild2";
            pbBuild2.Size = new System.Drawing.Size(50, 40);
            pbBuild2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild2.TabIndex = 161;
            pbBuild2.TabStop = false;
            pbBuild2.Visible = false;
            // 
            // pbBuild3
            // 
            pbBuild3.BackColor = System.Drawing.Color.Transparent;
            pbBuild3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild3.Location = new System.Drawing.Point(553, 834);
            pbBuild3.Name = "pbBuild3";
            pbBuild3.Size = new System.Drawing.Size(50, 40);
            pbBuild3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild3.TabIndex = 162;
            pbBuild3.TabStop = false;
            pbBuild3.Visible = false;
            // 
            // pbBuild4
            // 
            pbBuild4.BackColor = System.Drawing.Color.Transparent;
            pbBuild4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild4.Location = new System.Drawing.Point(655, 834);
            pbBuild4.Name = "pbBuild4";
            pbBuild4.Size = new System.Drawing.Size(50, 40);
            pbBuild4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild4.TabIndex = 163;
            pbBuild4.TabStop = false;
            pbBuild4.Visible = false;
            // 
            // pbBuild5
            // 
            pbBuild5.BackColor = System.Drawing.Color.Transparent;
            pbBuild5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild5.Location = new System.Drawing.Point(756, 835);
            pbBuild5.Name = "pbBuild5";
            pbBuild5.Size = new System.Drawing.Size(50, 40);
            pbBuild5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild5.TabIndex = 164;
            pbBuild5.TabStop = false;
            pbBuild5.Visible = false;
            // 
            // pbBuild6
            // 
            pbBuild6.BackColor = System.Drawing.Color.Transparent;
            pbBuild6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild6.Location = new System.Drawing.Point(828, 761);
            pbBuild6.Name = "pbBuild6";
            pbBuild6.Size = new System.Drawing.Size(40, 50);
            pbBuild6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild6.TabIndex = 165;
            pbBuild6.TabStop = false;
            pbBuild6.Visible = false;
            // 
            // pbBuild7
            // 
            pbBuild7.BackColor = System.Drawing.Color.Transparent;
            pbBuild7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild7.Location = new System.Drawing.Point(828, 657);
            pbBuild7.Name = "pbBuild7";
            pbBuild7.Size = new System.Drawing.Size(40, 50);
            pbBuild7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild7.TabIndex = 166;
            pbBuild7.TabStop = false;
            pbBuild7.Visible = false;
            // 
            // pbBuild8
            // 
            pbBuild8.BackColor = System.Drawing.Color.Transparent;
            pbBuild8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild8.Location = new System.Drawing.Point(828, 559);
            pbBuild8.Name = "pbBuild8";
            pbBuild8.Size = new System.Drawing.Size(40, 50);
            pbBuild8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild8.TabIndex = 167;
            pbBuild8.TabStop = false;
            pbBuild8.Visible = false;
            // 
            // pbBuild9
            // 
            pbBuild9.BackColor = System.Drawing.Color.Transparent;
            pbBuild9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild9.Location = new System.Drawing.Point(828, 458);
            pbBuild9.Name = "pbBuild9";
            pbBuild9.Size = new System.Drawing.Size(40, 50);
            pbBuild9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild9.TabIndex = 168;
            pbBuild9.TabStop = false;
            pbBuild9.Visible = false;
            // 
            // pbBuild10
            // 
            pbBuild10.BackColor = System.Drawing.Color.Transparent;
            pbBuild10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild10.Location = new System.Drawing.Point(828, 354);
            pbBuild10.Name = "pbBuild10";
            pbBuild10.Size = new System.Drawing.Size(40, 50);
            pbBuild10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild10.TabIndex = 169;
            pbBuild10.TabStop = false;
            pbBuild10.Visible = false;
            // 
            // pbBuild11
            // 
            pbBuild11.BackColor = System.Drawing.Color.Transparent;
            pbBuild11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild11.Location = new System.Drawing.Point(828, 159);
            pbBuild11.Name = "pbBuild11";
            pbBuild11.Size = new System.Drawing.Size(40, 50);
            pbBuild11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild11.TabIndex = 170;
            pbBuild11.TabStop = false;
            pbBuild11.Visible = false;
            // 
            // pbBuild13
            // 
            pbBuild13.BackColor = System.Drawing.Color.Transparent;
            pbBuild13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild13.Location = new System.Drawing.Point(655, 94);
            pbBuild13.Name = "pbBuild13";
            pbBuild13.Size = new System.Drawing.Size(50, 40);
            pbBuild13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild13.TabIndex = 171;
            pbBuild13.TabStop = false;
            pbBuild13.Visible = false;
            // 
            // pbBuild12
            // 
            pbBuild12.BackColor = System.Drawing.Color.Transparent;
            pbBuild12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild12.Location = new System.Drawing.Point(756, 94);
            pbBuild12.Name = "pbBuild12";
            pbBuild12.Size = new System.Drawing.Size(50, 40);
            pbBuild12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild12.TabIndex = 172;
            pbBuild12.TabStop = false;
            pbBuild12.Visible = false;
            // 
            // pbBuild14
            // 
            pbBuild14.BackColor = System.Drawing.Color.Transparent;
            pbBuild14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild14.Location = new System.Drawing.Point(457, 94);
            pbBuild14.Name = "pbBuild14";
            pbBuild14.Size = new System.Drawing.Size(50, 40);
            pbBuild14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild14.TabIndex = 173;
            pbBuild14.TabStop = false;
            pbBuild14.Visible = false;
            // 
            // pbBuild15
            // 
            pbBuild15.BackColor = System.Drawing.Color.Transparent;
            pbBuild15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild15.Location = new System.Drawing.Point(351, 94);
            pbBuild15.Name = "pbBuild15";
            pbBuild15.Size = new System.Drawing.Size(50, 40);
            pbBuild15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild15.TabIndex = 175;
            pbBuild15.TabStop = false;
            pbBuild15.Visible = false;
            // 
            // pbBuild16
            // 
            pbBuild16.BackColor = System.Drawing.Color.Transparent;
            pbBuild16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild16.Location = new System.Drawing.Point(255, 94);
            pbBuild16.Name = "pbBuild16";
            pbBuild16.Size = new System.Drawing.Size(50, 40);
            pbBuild16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild16.TabIndex = 176;
            pbBuild16.TabStop = false;
            pbBuild16.Visible = false;
            // 
            // pbBuild17
            // 
            pbBuild17.BackColor = System.Drawing.Color.Transparent;
            pbBuild17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild17.Location = new System.Drawing.Point(152, 94);
            pbBuild17.Name = "pbBuild17";
            pbBuild17.Size = new System.Drawing.Size(50, 40);
            pbBuild17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild17.TabIndex = 177;
            pbBuild17.TabStop = false;
            pbBuild17.Visible = false;
            // 
            // pbBuild18
            // 
            pbBuild18.BackColor = System.Drawing.Color.Transparent;
            pbBuild18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild18.Location = new System.Drawing.Point(88, 159);
            pbBuild18.Name = "pbBuild18";
            pbBuild18.Size = new System.Drawing.Size(40, 50);
            pbBuild18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild18.TabIndex = 178;
            pbBuild18.TabStop = false;
            pbBuild18.Visible = false;
            // 
            // pbBuild19
            // 
            pbBuild19.BackColor = System.Drawing.Color.Transparent;
            pbBuild19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild19.Location = new System.Drawing.Point(88, 261);
            pbBuild19.Name = "pbBuild19";
            pbBuild19.Size = new System.Drawing.Size(40, 50);
            pbBuild19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild19.TabIndex = 179;
            pbBuild19.TabStop = false;
            pbBuild19.Visible = false;
            // 
            // pbBuild20
            // 
            pbBuild20.BackColor = System.Drawing.Color.Transparent;
            pbBuild20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild20.Location = new System.Drawing.Point(88, 458);
            pbBuild20.Name = "pbBuild20";
            pbBuild20.Size = new System.Drawing.Size(40, 50);
            pbBuild20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild20.TabIndex = 180;
            pbBuild20.TabStop = false;
            pbBuild20.Visible = false;
            // 
            // pbBuild21
            // 
            pbBuild21.BackColor = System.Drawing.Color.Transparent;
            pbBuild21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild21.Location = new System.Drawing.Point(88, 657);
            pbBuild21.Name = "pbBuild21";
            pbBuild21.Size = new System.Drawing.Size(40, 50);
            pbBuild21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild21.TabIndex = 181;
            pbBuild21.TabStop = false;
            pbBuild21.Visible = false;
            // 
            // pbBuild22
            // 
            pbBuild22.BackColor = System.Drawing.Color.Transparent;
            pbBuild22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pbBuild22.Location = new System.Drawing.Point(88, 761);
            pbBuild22.Name = "pbBuild22";
            pbBuild22.Size = new System.Drawing.Size(40, 50);
            pbBuild22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbBuild22.TabIndex = 182;
            pbBuild22.TabStop = false;
            pbBuild22.Visible = false;
            // 
            // lbTurn
            // 
            lbTurn.AutoSize = true;
            lbTurn.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbTurn.ForeColor = System.Drawing.Color.Red;
            lbTurn.Location = new System.Drawing.Point(680, 153);
            lbTurn.Name = "lbTurn";
            lbTurn.Size = new System.Drawing.Size(86, 30);
            lbTurn.TabIndex = 186;
            lbTurn.Text = "Player1";
            // 
            // lbPlayer1
            // 
            lbPlayer1.AutoSize = true;
            lbPlayer1.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbPlayer1.ForeColor = System.Drawing.Color.Red;
            lbPlayer1.Location = new System.Drawing.Point(155, 771);
            lbPlayer1.Name = "lbPlayer1";
            lbPlayer1.Size = new System.Drawing.Size(73, 30);
            lbPlayer1.TabIndex = 187;
            lbPlayer1.Text = "label1";
            // 
            // lbPlayer2
            // 
            lbPlayer2.AutoSize = true;
            lbPlayer2.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbPlayer2.ForeColor = System.Drawing.Color.Blue;
            lbPlayer2.Location = new System.Drawing.Point(538, 771);
            lbPlayer2.Name = "lbPlayer2";
            lbPlayer2.Size = new System.Drawing.Size(73, 30);
            lbPlayer2.TabIndex = 188;
            lbPlayer2.Text = "label2";
            // 
            // timer1
            // 
            timer1.Interval = 500;
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Interval = 300;
            timer2.Tick += timer2_Tick;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            imageList1.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = System.Drawing.Color.Transparent;
            imageList1.Images.SetKeyName(0, "Dice1.png");
            imageList1.Images.SetKeyName(1, "Dice2.png");
            imageList1.Images.SetKeyName(2, "Dice3.png");
            imageList1.Images.SetKeyName(3, "Dice4.png");
            imageList1.Images.SetKeyName(4, "Dice5.png");
            imageList1.Images.SetKeyName(5, "Dice6.png");
            // 
            // timer3
            // 
            timer3.Interval = 200;
            timer3.Tick += timer3_Tick;
            // 
            // lbDice2
            // 
            lbDice2.AutoSize = true;
            lbDice2.Font = new System.Drawing.Font("맑은 고딕", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbDice2.Location = new System.Drawing.Point(695, 375);
            lbDice2.Name = "lbDice2";
            lbDice2.Size = new System.Drawing.Size(74, 86);
            lbDice2.TabIndex = 184;
            lbDice2.Text = "0";
            lbDice2.Visible = false;
            // 
            // lbDice1
            // 
            lbDice1.AutoSize = true;
            lbDice1.Font = new System.Drawing.Font("맑은 고딕", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbDice1.Location = new System.Drawing.Point(615, 375);
            lbDice1.Name = "lbDice1";
            lbDice1.Size = new System.Drawing.Size(74, 86);
            lbDice1.TabIndex = 183;
            lbDice1.Text = "0";
            lbDice1.Visible = false;
            // 
            // pbDice1
            // 
            pbDice1.BackColor = System.Drawing.Color.Transparent;
            pbDice1.Location = new System.Drawing.Point(466, 189);
            pbDice1.Name = "pbDice1";
            pbDice1.Size = new System.Drawing.Size(93, 87);
            pbDice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbDice1.TabIndex = 189;
            pbDice1.TabStop = false;
            // 
            // pbDice2
            // 
            pbDice2.BackColor = System.Drawing.Color.Transparent;
            pbDice2.Location = new System.Drawing.Point(573, 189);
            pbDice2.Name = "pbDice2";
            pbDice2.Size = new System.Drawing.Size(93, 87);
            pbDice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbDice2.TabIndex = 190;
            pbDice2.TabStop = false;
            // 
            // btnShowArea1
            // 
            btnShowArea1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnShowArea1.Location = new System.Drawing.Point(153, 719);
            btnShowArea1.Name = "btnShowArea1";
            btnShowArea1.Size = new System.Drawing.Size(96, 38);
            btnShowArea1.TabIndex = 191;
            btnShowArea1.Text = "보유 현황";
            btnShowArea1.UseVisualStyleBackColor = true;
            btnShowArea1.Click += btnShowArea1_Click;
            // 
            // btnShowArea2
            // 
            btnShowArea2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnShowArea2.Location = new System.Drawing.Point(528, 719);
            btnShowArea2.Name = "btnShowArea2";
            btnShowArea2.Size = new System.Drawing.Size(96, 38);
            btnShowArea2.TabIndex = 192;
            btnShowArea2.Text = "보유 현황";
            btnShowArea2.UseVisualStyleBackColor = true;
            btnShowArea2.Click += btnShowArea2_Click;
            // 
            // pbDice
            // 
            pbDice.Image = (System.Drawing.Image)resources.GetObject("pbDice.Image");
            pbDice.Location = new System.Drawing.Point(680, 191);
            pbDice.Name = "pbDice";
            pbDice.Size = new System.Drawing.Size(95, 90);
            pbDice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbDice.TabIndex = 193;
            pbDice.TabStop = false;
            pbDice.Click += pbDice_Click;
            // 
            // imageList2
            // 
            imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            imageList2.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imageList2.ImageStream");
            imageList2.TransparentColor = System.Drawing.Color.Transparent;
            imageList2.Images.SetKeyName(0, "Start1.png");
            imageList2.Images.SetKeyName(1, "Start2.png");
            // 
            // pbFundCoin
            // 
            pbFundCoin.BackColor = System.Drawing.Color.Transparent;
            pbFundCoin.Location = new System.Drawing.Point(870, 72);
            pbFundCoin.Name = "pbFundCoin";
            pbFundCoin.Size = new System.Drawing.Size(50, 57);
            pbFundCoin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pbFundCoin.TabIndex = 194;
            pbFundCoin.TabStop = false;
            // 
            // imageList3
            // 
            imageList3.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            imageList3.ImageStream = (System.Windows.Forms.ImageListStreamer)resources.GetObject("imageList3.ImageStream");
            imageList3.TransparentColor = System.Drawing.Color.Transparent;
            imageList3.Images.SetKeyName(0, "free-icon-dollar-coin-3016346.png");
            imageList3.Images.SetKeyName(1, "그림 (4).png");
            imageList3.Images.SetKeyName(2, "free-icon-coin-stacks-3016373.png");
            // 
            // MainBoard
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.LightGreen;
            ClientSize = new System.Drawing.Size(957, 968);
            Controls.Add(pbFundCoin);
            Controls.Add(pbDice);
            Controls.Add(btnShowArea2);
            Controls.Add(btnShowArea1);
            Controls.Add(pbDice2);
            Controls.Add(pbDice1);
            Controls.Add(lbPlayer2);
            Controls.Add(lbPlayer1);
            Controls.Add(lbTurn);
            Controls.Add(lbDice2);
            Controls.Add(lbDice1);
            Controls.Add(pbBuild22);
            Controls.Add(pbBuild21);
            Controls.Add(pbBuild20);
            Controls.Add(pbBuild19);
            Controls.Add(pbBuild18);
            Controls.Add(pbBuild17);
            Controls.Add(pbBuild16);
            Controls.Add(pbBuild15);
            Controls.Add(pbBuild14);
            Controls.Add(pbBuild12);
            Controls.Add(pbBuild13);
            Controls.Add(pbBuild11);
            Controls.Add(pbBuild10);
            Controls.Add(pbBuild9);
            Controls.Add(pbBuild8);
            Controls.Add(pbBuild7);
            Controls.Add(pbBuild6);
            Controls.Add(pbBuild5);
            Controls.Add(pbBuild4);
            Controls.Add(pbBuild3);
            Controls.Add(pbBuild2);
            Controls.Add(pbBuild1);
            Controls.Add(pbBuild0);
            Controls.Add(pbPlayer2_5);
            Controls.Add(pbPlayer1_5);
            Controls.Add(pbPlayer2_3);
            Controls.Add(pbPlayer1_3);
            Controls.Add(pbPlayer2_8);
            Controls.Add(pbPlayer1_8);
            Controls.Add(pbPlayer2_0);
            Controls.Add(pbPlayer1_0);
            Controls.Add(pbPlayer1_24);
            Controls.Add(pbPlayer2_24);
            Controls.Add(pbPlayer1_16);
            Controls.Add(pbPlayer2_16);
            Controls.Add(pbPlayer1_21);
            Controls.Add(pbPlayer2_21);
            Controls.Add(pbPlayer1_19);
            Controls.Add(pbPlayer2_19);
            Controls.Add(pbPlayer2_14);
            Controls.Add(pbPlayer1_14);
            Controls.Add(pbPlayer2_11);
            Controls.Add(pbPlayer1_11);
            Controls.Add(pbPlayer1_30);
            Controls.Add(pbPlayer2_30);
            Controls.Add(pbPlayer1_27);
            Controls.Add(pbPlayer2_27);
            Controls.Add(pbPlayer1_31);
            Controls.Add(pbPlayer2_31);
            Controls.Add(pbPlayer1_29);
            Controls.Add(pbPlayer2_29);
            Controls.Add(pbPlayer1_28);
            Controls.Add(pbPlayer2_28);
            Controls.Add(pbPlayer1_26);
            Controls.Add(pbPlayer2_26);
            Controls.Add(pbPlayer1_25);
            Controls.Add(pbPlayer2_25);
            Controls.Add(pbPlayer1_23);
            Controls.Add(pbPlayer2_23);
            Controls.Add(pbPlayer1_22);
            Controls.Add(pbPlayer2_22);
            Controls.Add(pbPlayer1_20);
            Controls.Add(pbPlayer2_20);
            Controls.Add(pbPlayer1_18);
            Controls.Add(pbPlayer2_18);
            Controls.Add(pbPlayer1_17);
            Controls.Add(pbPlayer2_17);
            Controls.Add(pbPlayer2_15);
            Controls.Add(pbPlayer1_15);
            Controls.Add(pbPlayer2_13);
            Controls.Add(pbPlayer1_13);
            Controls.Add(pbPlayer2_12);
            Controls.Add(pbPlayer1_12);
            Controls.Add(pbPlayer2_10);
            Controls.Add(pbPlayer1_10);
            Controls.Add(pbPlayer2_9);
            Controls.Add(pbPlayer1_9);
            Controls.Add(pbPlayer2_7);
            Controls.Add(pbPlayer1_7);
            Controls.Add(pbPlayer2_6);
            Controls.Add(pbPlayer1_6);
            Controls.Add(pbPlayer2_4);
            Controls.Add(pbPlayer1_4);
            Controls.Add(pbPlayer2_2);
            Controls.Add(pbPlayer1_2);
            Controls.Add(pbPlayer2_1);
            Controls.Add(pbPlayer1_1);
            Controls.Add(pbImage);
            Controls.Add(pbArea15);
            Controls.Add(pbArea14);
            Controls.Add(pbArea13);
            Controls.Add(pbArea12);
            Controls.Add(pbArea11);
            Controls.Add(pbArea10);
            Controls.Add(pbArea9);
            Controls.Add(pbArea16);
            Controls.Add(pbArea17);
            Controls.Add(pbArea18);
            Controls.Add(pbArea19);
            Controls.Add(pbArea20);
            Controls.Add(pbArea21);
            Controls.Add(pbArea22);
            Controls.Add(pbArea23);
            Controls.Add(pbArea24);
            Controls.Add(pbArea25);
            Controls.Add(pbArea26);
            Controls.Add(pbArea27);
            Controls.Add(pbArea28);
            Controls.Add(pbArea29);
            Controls.Add(pbArea30);
            Controls.Add(pbArea8);
            Controls.Add(pbArea7);
            Controls.Add(pbArea6);
            Controls.Add(pbArea5);
            Controls.Add(pbArea4);
            Controls.Add(pbArea3);
            Controls.Add(pbArea2);
            Controls.Add(pbGoldKey);
            Controls.Add(pbArea31);
            Controls.Add(pbArea1);
            Controls.Add(pbArea0);
            Name = "MainBoard";
            Text = "부루마블";
            ((System.ComponentModel.ISupportInitialize)pbArea1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea0).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea31).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbGoldKey).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea30).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbImage).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_31).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_31).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_30).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_30).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_0).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_0).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer2_5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbPlayer1_5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild0).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbArea29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBuild22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbDice1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbDice2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbDice).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbFundCoin).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.PictureBox pbArea1;
        private System.Windows.Forms.PictureBox pbArea0;
        private System.Windows.Forms.PictureBox pbArea31;
        private System.Windows.Forms.PictureBox pbGoldKey;
        private System.Windows.Forms.PictureBox pbArea2;
        private System.Windows.Forms.PictureBox pbArea3;
        private System.Windows.Forms.PictureBox pbArea6;
        private System.Windows.Forms.PictureBox pbArea5;
        private System.Windows.Forms.PictureBox pbArea4;
        private System.Windows.Forms.PictureBox pbArea7;
        private System.Windows.Forms.PictureBox pbArea8;
        private System.Windows.Forms.PictureBox pbArea30;
        private System.Windows.Forms.PictureBox pbArea26;
        private System.Windows.Forms.PictureBox pbArea27;
        private System.Windows.Forms.PictureBox pbArea28;
        private System.Windows.Forms.PictureBox pbArea25;
        private System.Windows.Forms.PictureBox pbArea24;
        private System.Windows.Forms.PictureBox pbArea16;
        private System.Windows.Forms.PictureBox pbArea17;
        private System.Windows.Forms.PictureBox pbArea18;
        private System.Windows.Forms.PictureBox pbArea19;
        private System.Windows.Forms.PictureBox pbArea20;
        private System.Windows.Forms.PictureBox pbArea21;
        private System.Windows.Forms.PictureBox pbArea22;
        private System.Windows.Forms.PictureBox pbArea23;
        private System.Windows.Forms.PictureBox pbArea15;
        private System.Windows.Forms.PictureBox pbArea14;
        private System.Windows.Forms.PictureBox pbArea13;
        private System.Windows.Forms.PictureBox pbArea12;
        private System.Windows.Forms.PictureBox pbArea11;
        private System.Windows.Forms.PictureBox pbArea10;
        private System.Windows.Forms.PictureBox pbArea9;
        private System.Windows.Forms.PictureBox pbImage;
        private System.Windows.Forms.PictureBox pbPlayer1_1;
        private System.Windows.Forms.PictureBox pbPlayer2_1;
        private System.Windows.Forms.PictureBox pbPlayer2_2;
        private System.Windows.Forms.PictureBox pbPlayer1_2;
        private System.Windows.Forms.PictureBox pbPlayer2_4;
        private System.Windows.Forms.PictureBox pbPlayer1_4;
        private System.Windows.Forms.PictureBox pbPlayer2_6;
        private System.Windows.Forms.PictureBox pbPlayer1_6;
        private System.Windows.Forms.PictureBox pbPlayer2_7;
        private System.Windows.Forms.PictureBox pbPlayer1_7;
        private System.Windows.Forms.PictureBox pbPlayer1_9;
        private System.Windows.Forms.PictureBox pbPlayer2_9;
        private System.Windows.Forms.PictureBox pbPlayer2_10;
        private System.Windows.Forms.PictureBox pbPlayer1_10;
        private System.Windows.Forms.PictureBox pbPlayer2_12;
        private System.Windows.Forms.PictureBox pbPlayer1_12;
        private System.Windows.Forms.PictureBox pbPlayer2_13;
        private System.Windows.Forms.PictureBox pbPlayer1_13;
        private System.Windows.Forms.PictureBox pbPlayer2_15;
        private System.Windows.Forms.PictureBox pbPlayer1_15;
        private System.Windows.Forms.PictureBox pbPlayer1_17;
        private System.Windows.Forms.PictureBox pbPlayer2_17;
        private System.Windows.Forms.PictureBox pbPlayer1_18;
        private System.Windows.Forms.PictureBox pbPlayer2_18;
        private System.Windows.Forms.PictureBox pbPlayer1_20;
        private System.Windows.Forms.PictureBox pbPlayer2_20;
        private System.Windows.Forms.PictureBox pbPlayer1_22;
        private System.Windows.Forms.PictureBox pbPlayer2_22;
        private System.Windows.Forms.PictureBox pbPlayer1_23;
        private System.Windows.Forms.PictureBox pbPlayer2_23;
        private System.Windows.Forms.PictureBox pbPlayer1_25;
        private System.Windows.Forms.PictureBox pbPlayer2_25;
        private System.Windows.Forms.PictureBox pbPlayer1_26;
        private System.Windows.Forms.PictureBox pbPlayer2_26;
        private System.Windows.Forms.PictureBox pbPlayer1_28;
        private System.Windows.Forms.PictureBox pbPlayer2_28;
        private System.Windows.Forms.PictureBox pbPlayer1_29;
        private System.Windows.Forms.PictureBox pbPlayer2_29;
        private System.Windows.Forms.PictureBox pbPlayer1_31;
        private System.Windows.Forms.PictureBox pbPlayer2_31;
        private System.Windows.Forms.PictureBox pbPlayer1_27;
        private System.Windows.Forms.PictureBox pbPlayer2_27;
        private System.Windows.Forms.PictureBox pbPlayer1_30;
        private System.Windows.Forms.PictureBox pbPlayer2_30;
        private System.Windows.Forms.PictureBox pbPlayer2_11;
        private System.Windows.Forms.PictureBox pbPlayer1_11;
        private System.Windows.Forms.PictureBox pbPlayer2_14;
        private System.Windows.Forms.PictureBox pbPlayer1_14;
        private System.Windows.Forms.PictureBox pbPlayer1_19;
        private System.Windows.Forms.PictureBox pbPlayer2_19;
        private System.Windows.Forms.PictureBox pbPlayer1_21;
        private System.Windows.Forms.PictureBox pbPlayer2_21;
        private System.Windows.Forms.PictureBox pbPlayer1_16;
        private System.Windows.Forms.PictureBox pbPlayer2_16;
        private System.Windows.Forms.PictureBox pbPlayer1_24;
        private System.Windows.Forms.PictureBox pbPlayer2_24;
        private System.Windows.Forms.PictureBox pbPlayer2_0;
        private System.Windows.Forms.PictureBox pbPlayer1_0;
        private System.Windows.Forms.PictureBox pbPlayer2_8;
        private System.Windows.Forms.PictureBox pbPlayer1_8;
        private System.Windows.Forms.PictureBox pbPlayer2_3;
        private System.Windows.Forms.PictureBox pbPlayer1_3;
        private System.Windows.Forms.PictureBox pbPlayer2_5;
        private System.Windows.Forms.PictureBox pbPlayer1_5;
        private System.Windows.Forms.PictureBox pbBuild0;
        private System.Windows.Forms.PictureBox pbArea29;
        private System.Windows.Forms.PictureBox pbBuild1;
        private System.Windows.Forms.PictureBox pbBuild2;
        private System.Windows.Forms.PictureBox pbBuild3;
        private System.Windows.Forms.PictureBox pbBuild4;
        private System.Windows.Forms.PictureBox pbBuild5;
        private System.Windows.Forms.PictureBox pbBuild6;
        private System.Windows.Forms.PictureBox pbBuild7;
        private System.Windows.Forms.PictureBox pbBuild8;
        private System.Windows.Forms.PictureBox pbBuild9;
        private System.Windows.Forms.PictureBox pbBuild10;
        private System.Windows.Forms.PictureBox pbBuild11;
        private System.Windows.Forms.PictureBox pbBuild13;
        private System.Windows.Forms.PictureBox pbBuild12;
        private System.Windows.Forms.PictureBox pbBuild14;
        private System.Windows.Forms.PictureBox pbBuild15;
        private System.Windows.Forms.PictureBox pbBuild16;
        private System.Windows.Forms.PictureBox pbBuild17;
        private System.Windows.Forms.PictureBox pbBuild18;
        private System.Windows.Forms.PictureBox pbBuild19;
        private System.Windows.Forms.PictureBox pbBuild20;
        private System.Windows.Forms.PictureBox pbBuild21;
        private System.Windows.Forms.PictureBox pbBuild22;
        private System.Windows.Forms.Label lbTurn;
        private System.Windows.Forms.Label lbPlayer1;
        private System.Windows.Forms.Label lbPlayer2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label lbDice2;
        private System.Windows.Forms.Label lbDice1;
        private System.Windows.Forms.PictureBox pbDice1;
        private System.Windows.Forms.PictureBox pbDice2;
        private System.Windows.Forms.Button btnShowArea1;
        private System.Windows.Forms.Button btnShowArea2;
        private System.Windows.Forms.PictureBox pbDice;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.PictureBox pbFundCoin;
        private System.Windows.Forms.ImageList imageList3;
    }
}
